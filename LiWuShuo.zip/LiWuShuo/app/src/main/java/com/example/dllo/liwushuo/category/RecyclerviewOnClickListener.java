package com.example.dllo.liwushuo.category;

/**
 * Created by dllo on 16/6/3.
 */
public interface RecyclerviewOnClickListener {
    void onClick(int position);
}
