package com.example.dllo.liwushuo.search;

import android.view.View;

import com.example.dllo.liwushuo.R;
import com.example.dllo.liwushuo.base.BaseFragment;

/**
 * Created by dllo on 16/6/6.
 */
public class SearchDetailRaidersFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_search_detail_raiders;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
