package com.example.dllo.liwushuo.home.bean;

import java.util.List;

/**
 * Created by dllo on 16/6/3.
 */
public class ConmentBean {

    /**
     * code : 200
     * data : {"comments":[{"content":"我们现在要網shang赚钱人手多名，帮忙，路文件人手.做打字人员，不用，排版，每天稳定有，150园，按天算， 伽QQ:63.54.08.508  ！ 来咨询哦","created_at":1464872795,"does_like":false,"fake_likes_count":0,"id":1137460,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160602/1a54892e4_a-w180","can_mobile_login":false,"guest_uuid":null,"id":7101532,"nickname":"用业余时间换钱","role":0}},{"content":"爸爸","created_at":1464665916,"does_like":false,"fake_likes_count":0,"id":1121725,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"","can_mobile_login":true,"guest_uuid":null,"id":7061546,"nickname":"18742518490","role":0}},{"content":"我也是，不会化妆！","created_at":1464244073,"does_like":false,"fake_likes_count":0,"id":1086893,"likes_count":0,"post_id":1024345,"replied_comment":{"content":"会化妆的拿啥都能画，像我这样的手残党，拿一堆神器画出来也是鬼😂","created_at":1464169344,"fake_likes_count":0,"id":1080754,"likes_count":0,"post_id":1024345,"reply_to_id":null,"show":true,"status":1,"user_id":2960133},"replied_user":{"avatar_url":"http://img01.liwushuo.com/avatar/150730/c52eb86a1_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2960133,"nickname":"浅笑心柔◎","role":0},"reply_to_id":1080754,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/160524/fc8c8cd8b_a-w180","can_mobile_login":false,"guest_uuid":null,"id":7074396,"nickname":"娉打字员扣1615346083","role":0}},{"content":"淡妆最好看了","created_at":1464236010,"does_like":false,"fake_likes_count":0,"id":1086433,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160524/e030eb522_a-w180","can_mobile_login":true,"guest_uuid":null,"id":7001276,"nickname":"兰妹","role":0}},{"content":"棉签  绝对是棉签   超级好用","created_at":1464221255,"does_like":false,"fake_likes_count":0,"id":1085550,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150330/a8109f95c_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1787123,"nickname":"  WWWe","role":0}},{"content":"葫芦头、","created_at":1464196198,"does_like":false,"fake_likes_count":0,"id":1084677,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLAY1h1ez3Jw024j","can_mobile_login":false,"guest_uuid":null,"id":6120022,"nickname":"米花","role":0}},{"content":"一开始觉得素颜是最美我素颜我骄傲，于是从来没化过妆弄过头发，后来真的感觉人要活得精彩一点就要适当的把自己打扮得美丽一点，因为现在就是个看脸的社会啊。重点来了，我素颜一样美哈哈哈","created_at":1464192380,"does_like":false,"fake_likes_count":0,"id":1084326,"likes_count":20,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20160526/5oaami465_i.png-w180","can_mobile_login":true,"guest_uuid":null,"id":2536917,"nickname":"Butterfly","role":0}},{"content":"从来不化妆☹️","created_at":1464186822,"does_like":false,"fake_likes_count":0,"id":1083199,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/160524/5c2f7712a_a-w180","can_mobile_login":true,"guest_uuid":null,"id":2560630,"nickname":"13535832707","role":0}},{"content":"其实我想说素颜最美的，但现在不化妆真的不好意思出门啊。","created_at":1464183406,"does_like":false,"fake_likes_count":0,"id":1082377,"likes_count":17,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/151102/15d319fa2_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5124471,"nickname":"末夜","role":0}},{"content":"我觉得东西不重要，重要的还是手啊！啊😱","created_at":1464182756,"does_like":false,"fake_likes_count":0,"id":1082234,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/141115/7070be5ac_a.jpg-w180","can_mobile_login":false,"guest_uuid":null,"id":798534,"nickname":"叫我小聪明。","role":0}},{"content":"素颜最美才是真的美～～～","created_at":1464181612,"does_like":false,"fake_likes_count":0,"id":1081974,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160525/406d13f2e_a-w180","can_mobile_login":false,"guest_uuid":null,"id":5377950,"nickname":"kiyomi","role":0}},{"content":"化妆蛋\u2026手残必备","created_at":1464180748,"does_like":false,"fake_likes_count":0,"id":1081775,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/20150206/wrqjhq94x_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1262691,"nickname":"J-ovy","role":0}},{"content":"勺子是万能的，可以消眼肿，涂睫毛时也可以用","created_at":1464180388,"does_like":false,"fake_likes_count":0,"id":1081705,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160325/7f22354ce_a-w180","can_mobile_login":false,"guest_uuid":null,"id":1066650,"nickname":"Waiting-莫凝汐","role":0}},{"content":"手！","created_at":1464175982,"does_like":false,"fake_likes_count":0,"id":1081140,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150421/0b2c410bb_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2025289,"nickname":"偏宕","role":0}},{"content":"画得再美也不是真正的自己","created_at":1464175063,"does_like":false,"fake_likes_count":0,"id":1081093,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160521/5c92d32f8_a-w180","can_mobile_login":false,"guest_uuid":null,"id":1999906,"nickname":"阿喵哦？？^","role":0}},{"content":"不会化妆😂😂","created_at":1464174249,"does_like":false,"fake_likes_count":0,"id":1081035,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160326/b7c5549b3_a-w180","can_mobile_login":true,"guest_uuid":null,"id":6883791,"nickname":"15735644342","role":0}},{"content":"用口红💄💄💄遮黑眼圈比什么遮瑕都好用，你们可以试试！！","created_at":1464174231,"does_like":false,"fake_likes_count":0,"id":1081034,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/20150804/1yp0b9kab_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":5001371,"nickname":"发条柠檬_啊哦","role":0}},{"content":"不化妆的人到此一游","created_at":1464173822,"does_like":false,"fake_likes_count":0,"id":1081007,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160220/eeb61b9fb_a-w180","can_mobile_login":false,"guest_uuid":null,"id":868820,"nickname":"♚歆久","role":0}},{"content":"管他呢，反正手残党也没折","created_at":1464173265,"does_like":false,"fake_likes_count":0,"id":1080976,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150306/f1d6af820_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1513601,"nickname":"随遇而安","role":0}},{"content":"什么好用不好用的，遇到手残一切完蛋","created_at":1464172560,"does_like":false,"fake_likes_count":0,"id":1080935,"likes_count":2,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/20160215/5owc1kljt_i.png-w180","can_mobile_login":true,"guest_uuid":null,"id":6618203,"nickname":"effaceable","role":0}}],"paging":{"next_url":"http://api.liwushuo.com/v2/posts/1024345/comments?limit=20&offset=20"}}
     * message : OK
     */

    private int code;
    /**
     * comments : [{"content":"我们现在要網shang赚钱人手多名，帮忙，路文件人手.做打字人员，不用，排版，每天稳定有，150园，按天算， 伽QQ:63.54.08.508  ！ 来咨询哦","created_at":1464872795,"does_like":false,"fake_likes_count":0,"id":1137460,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160602/1a54892e4_a-w180","can_mobile_login":false,"guest_uuid":null,"id":7101532,"nickname":"用业余时间换钱","role":0}},{"content":"爸爸","created_at":1464665916,"does_like":false,"fake_likes_count":0,"id":1121725,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"","can_mobile_login":true,"guest_uuid":null,"id":7061546,"nickname":"18742518490","role":0}},{"content":"我也是，不会化妆！","created_at":1464244073,"does_like":false,"fake_likes_count":0,"id":1086893,"likes_count":0,"post_id":1024345,"replied_comment":{"content":"会化妆的拿啥都能画，像我这样的手残党，拿一堆神器画出来也是鬼😂","created_at":1464169344,"fake_likes_count":0,"id":1080754,"likes_count":0,"post_id":1024345,"reply_to_id":null,"show":true,"status":1,"user_id":2960133},"replied_user":{"avatar_url":"http://img01.liwushuo.com/avatar/150730/c52eb86a1_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2960133,"nickname":"浅笑心柔◎","role":0},"reply_to_id":1080754,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/160524/fc8c8cd8b_a-w180","can_mobile_login":false,"guest_uuid":null,"id":7074396,"nickname":"娉打字员扣1615346083","role":0}},{"content":"淡妆最好看了","created_at":1464236010,"does_like":false,"fake_likes_count":0,"id":1086433,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160524/e030eb522_a-w180","can_mobile_login":true,"guest_uuid":null,"id":7001276,"nickname":"兰妹","role":0}},{"content":"棉签  绝对是棉签   超级好用","created_at":1464221255,"does_like":false,"fake_likes_count":0,"id":1085550,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/150330/a8109f95c_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1787123,"nickname":"  WWWe","role":0}},{"content":"葫芦头、","created_at":1464196198,"does_like":false,"fake_likes_count":0,"id":1084677,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLAY1h1ez3Jw024j","can_mobile_login":false,"guest_uuid":null,"id":6120022,"nickname":"米花","role":0}},{"content":"一开始觉得素颜是最美我素颜我骄傲，于是从来没化过妆弄过头发，后来真的感觉人要活得精彩一点就要适当的把自己打扮得美丽一点，因为现在就是个看脸的社会啊。重点来了，我素颜一样美哈哈哈","created_at":1464192380,"does_like":false,"fake_likes_count":0,"id":1084326,"likes_count":20,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/20160526/5oaami465_i.png-w180","can_mobile_login":true,"guest_uuid":null,"id":2536917,"nickname":"Butterfly","role":0}},{"content":"从来不化妆☹️","created_at":1464186822,"does_like":false,"fake_likes_count":0,"id":1083199,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/160524/5c2f7712a_a-w180","can_mobile_login":true,"guest_uuid":null,"id":2560630,"nickname":"13535832707","role":0}},{"content":"其实我想说素颜最美的，但现在不化妆真的不好意思出门啊。","created_at":1464183406,"does_like":false,"fake_likes_count":0,"id":1082377,"likes_count":17,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/151102/15d319fa2_a-w180","can_mobile_login":true,"guest_uuid":null,"id":5124471,"nickname":"末夜","role":0}},{"content":"我觉得东西不重要，重要的还是手啊！啊😱","created_at":1464182756,"does_like":false,"fake_likes_count":0,"id":1082234,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/141115/7070be5ac_a.jpg-w180","can_mobile_login":false,"guest_uuid":null,"id":798534,"nickname":"叫我小聪明。","role":0}},{"content":"素颜最美才是真的美～～～","created_at":1464181612,"does_like":false,"fake_likes_count":0,"id":1081974,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160525/406d13f2e_a-w180","can_mobile_login":false,"guest_uuid":null,"id":5377950,"nickname":"kiyomi","role":0}},{"content":"化妆蛋\u2026手残必备","created_at":1464180748,"does_like":false,"fake_likes_count":0,"id":1081775,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/20150206/wrqjhq94x_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1262691,"nickname":"J-ovy","role":0}},{"content":"勺子是万能的，可以消眼肿，涂睫毛时也可以用","created_at":1464180388,"does_like":false,"fake_likes_count":0,"id":1081705,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160325/7f22354ce_a-w180","can_mobile_login":false,"guest_uuid":null,"id":1066650,"nickname":"Waiting-莫凝汐","role":0}},{"content":"手！","created_at":1464175982,"does_like":false,"fake_likes_count":0,"id":1081140,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/150421/0b2c410bb_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":2025289,"nickname":"偏宕","role":0}},{"content":"画得再美也不是真正的自己","created_at":1464175063,"does_like":false,"fake_likes_count":0,"id":1081093,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160521/5c92d32f8_a-w180","can_mobile_login":false,"guest_uuid":null,"id":1999906,"nickname":"阿喵哦？？^","role":0}},{"content":"不会化妆😂😂","created_at":1464174249,"does_like":false,"fake_likes_count":0,"id":1081035,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img01.liwushuo.com/avatar/160326/b7c5549b3_a-w180","can_mobile_login":true,"guest_uuid":null,"id":6883791,"nickname":"15735644342","role":0}},{"content":"用口红💄💄💄遮黑眼圈比什么遮瑕都好用，你们可以试试！！","created_at":1464174231,"does_like":false,"fake_likes_count":0,"id":1081034,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/20150804/1yp0b9kab_i.png-w180","can_mobile_login":false,"guest_uuid":null,"id":5001371,"nickname":"发条柠檬_啊哦","role":0}},{"content":"不化妆的人到此一游","created_at":1464173822,"does_like":false,"fake_likes_count":0,"id":1081007,"likes_count":0,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/160220/eeb61b9fb_a-w180","can_mobile_login":false,"guest_uuid":null,"id":868820,"nickname":"♚歆久","role":0}},{"content":"管他呢，反正手残党也没折","created_at":1464173265,"does_like":false,"fake_likes_count":0,"id":1080976,"likes_count":1,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img02.liwushuo.com/avatar/150306/f1d6af820_a.png-w180","can_mobile_login":false,"guest_uuid":null,"id":1513601,"nickname":"随遇而安","role":0}},{"content":"什么好用不好用的，遇到手残一切完蛋","created_at":1464172560,"does_like":false,"fake_likes_count":0,"id":1080935,"likes_count":2,"post_id":1024345,"reply_to_id":null,"user":{"avatar_url":"http://img03.liwushuo.com/avatar/20160215/5owc1kljt_i.png-w180","can_mobile_login":true,"guest_uuid":null,"id":6618203,"nickname":"effaceable","role":0}}]
     * paging : {"next_url":"http://api.liwushuo.com/v2/posts/1024345/comments?limit=20&offset=20"}
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        /**
         * next_url : http://api.liwushuo.com/v2/posts/1024345/comments?limit=20&offset=20
         */

        private PagingBean paging;
        /**
         * content : 我们现在要網shang赚钱人手多名，帮忙，路文件人手.做打字人员，不用，排版，每天稳定有，150园，按天算， 伽QQ:63.54.08.508  ！ 来咨询哦
         * created_at : 1464872795
         * does_like : false
         * fake_likes_count : 0
         * id : 1137460
         * likes_count : 0
         * post_id : 1024345
         * reply_to_id : null
         * user : {"avatar_url":"http://img02.liwushuo.com/avatar/160602/1a54892e4_a-w180","can_mobile_login":false,"guest_uuid":null,"id":7101532,"nickname":"用业余时间换钱","role":0}
         */

        private List<CommentsBean> comments;

        public PagingBean getPaging() {
            return paging;
        }

        public void setPaging(PagingBean paging) {
            this.paging = paging;
        }

        public List<CommentsBean> getComments() {
            return comments;
        }

        public void setComments(List<CommentsBean> comments) {
            this.comments = comments;
        }

        public static class PagingBean {
            private String next_url;

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class CommentsBean {
            private String content;
            private int created_at;
            private boolean does_like;
            private int fake_likes_count;
            private int id;
            private int likes_count;
            private int post_id;
            private Object reply_to_id;
            /**
             * avatar_url : http://img02.liwushuo.com/avatar/160602/1a54892e4_a-w180
             * can_mobile_login : false
             * guest_uuid : null
             * id : 7101532
             * nickname : 用业余时间换钱
             * role : 0
             */

            private UserBean user;

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public int getCreated_at() {
                return created_at;
            }

            public void setCreated_at(int created_at) {
                this.created_at = created_at;
            }

            public boolean isDoes_like() {
                return does_like;
            }

            public void setDoes_like(boolean does_like) {
                this.does_like = does_like;
            }

            public int getFake_likes_count() {
                return fake_likes_count;
            }

            public void setFake_likes_count(int fake_likes_count) {
                this.fake_likes_count = fake_likes_count;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getLikes_count() {
                return likes_count;
            }

            public void setLikes_count(int likes_count) {
                this.likes_count = likes_count;
            }

            public int getPost_id() {
                return post_id;
            }

            public void setPost_id(int post_id) {
                this.post_id = post_id;
            }

            public Object getReply_to_id() {
                return reply_to_id;
            }

            public void setReply_to_id(Object reply_to_id) {
                this.reply_to_id = reply_to_id;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public static class UserBean {
                private String avatar_url;
                private boolean can_mobile_login;
                private Object guest_uuid;
                private int id;
                private String nickname;
                private int role;

                public String getAvatar_url() {
                    return avatar_url;
                }

                public void setAvatar_url(String avatar_url) {
                    this.avatar_url = avatar_url;
                }

                public boolean isCan_mobile_login() {
                    return can_mobile_login;
                }

                public void setCan_mobile_login(boolean can_mobile_login) {
                    this.can_mobile_login = can_mobile_login;
                }

                public Object getGuest_uuid() {
                    return guest_uuid;
                }

                public void setGuest_uuid(Object guest_uuid) {
                    this.guest_uuid = guest_uuid;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getNickname() {
                    return nickname;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }

                public int getRole() {
                    return role;
                }

                public void setRole(int role) {
                    this.role = role;
                }
            }
        }
    }
}
