package com.example.dllo.liwushuo.home;

/**
 * Created by dllo on 16/6/4.
 */
public interface HomeRecyclerVIewOnClickListener {
    void onClick(int position);
}
