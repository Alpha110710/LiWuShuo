package com.example.dllo.liwushuo.profile;

import android.view.View;

import com.example.dllo.liwushuo.R;
import com.example.dllo.liwushuo.base.BaseFragment;

/**
 * Created by dllo on 16/5/21.
 */
public class RaidersProfileFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_profile_raiders;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
