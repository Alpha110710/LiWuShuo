package com.example.dllo.liwushuo.home.bean;

import java.util.List;

/**
 * Created by dllo on 16/5/26.
 */
public class NormalListviewBean {

    /**
     * code : 200
     * data : {"items":[{"ad_monitors":[],"content_type":3,"content_url":"http://www.liwushuo.com/posts/1043410/content","cover_image_url":"http://img03.liwushuo.com/image/160518/bf4sc3f3m.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160518/bf4sc3f3m.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965987,"editor_id":1045,"feature_list":[8,1,5,6],"hidden_cover_image":false,"id":1043410,"labels":[],"liked":false,"likes_count":22565,"preview_items":[{"cover_image_url":"http://img.alicdn.com/imgextra/i8/TB1iyWOMXXXXXXkXVXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056246","price":"55.00","shop_type":0,"title":"竖条纹理撞色圆领短袖T恤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i3/TB1EHy6MXXXXXXXXpXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056249","price":"122.00","shop_type":0,"title":"不对称压褶休闲短裤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i2/TB1Qp5dMpXXXXa0XVXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056250","price":"143.00","shop_type":0,"title":"插肩撞色字母短袖T恤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i8/TB1Y2DiHVXXXXbLXFXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056251","price":"69.00","shop_type":0,"title":"百搭修身运动短裤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/d8xya3fh2.jpg-w720","fixed_price":null,"item_id":"1056248","price":"69.00","shop_type":0,"title":"灰白竖条短款短袖t恤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/ia9ej3o0q.jpg-w720","fixed_price":null,"item_id":"1056244","price":"79.00","shop_type":0,"title":"黑白侧条九分宽腿裤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/vwlijvteo.jpg-w720","fixed_price":null,"item_id":"1056243","price":"47.00","shop_type":0,"title":"无袖中长款可乐印花T恤"}],"published_at":1463875200,"share_msg":"最近的戛纳是个热闹的地方，因为第69届电影节来了，除了期待各项奖项花落谁家，当然就是看各家明星的街拍照过眼瘾了。除了红毯，他们平常的装扮我们还是可以学习一下的，比如，集Smart和Chic于一身的Sporty look！又时髦又实穿还能拥有舒适自由的穿衣大招get好了吗？","short_title":"运动风","status":0,"template":"","title":"第18期 ｜ 依旧不过时的运动风大势，请跟上！","type":"post","updated_at":1463472930,"url":"http://www.liwushuo.com/posts/1043410"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043500/content","cover_image_url":"http://img02.liwushuo.com/image/160520/nqyn21b3q.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160520/nqyn21b3q.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965976,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043500,"labels":[],"liked":false,"likes_count":22958,"published_at":1463886000,"share_msg":"很多女神都很喜欢偏文艺的连衣裙，因为如果衣服太甜美显得萝莉，太超酷又显得中性，太利落显得太职业了，就这种文艺范的连衣裙，简单优雅，看上去十分有质感！穿上文艺范连衣裙，你也是女神。","short_title":"","status":0,"template":"","title":"第18期 | 女神养成记，只需一条文艺范连衣裙","type":"post","updated_at":1463713623,"url":"http://www.liwushuo.com/posts/1043500"},{"ad_monitors":[],"content_type":3,"content_url":"http://www.liwushuo.com/posts/1043431/content","cover_image_url":"http://img01.liwushuo.com/image/160519/u6brosgkc.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160519/u6brosgkc.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965960,"editor_id":1045,"feature_list":[8,5,6],"hidden_cover_image":false,"id":1043431,"labels":[],"liked":false,"likes_count":24167,"preview_items":[{"cover_image_url":"http://img01.liwushuo.com/image/160517/8gsd1uk29.jpg-w720","fixed_price":null,"item_id":"1056351","price":"72.00","shop_type":0,"title":"五分袖纯棉修身打底衫"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/zdw07i65x.jpg-w720","fixed_price":null,"item_id":"1056344","price":"142.00","shop_type":0,"title":"百搭开叉中长款半身裙"},{"cover_image_url":"http://img01.liwushuo.com/image/160518/nincfphz5_w.jpg-w720","fixed_price":null,"item_id":"1056346","price":"168.00","shop_type":0,"title":"勿忘草蓝麂皮绒开衩半身裙"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/0klpv2pex.jpg-w720","fixed_price":null,"item_id":"1056349","price":"138.00","shop_type":0,"title":"宽松V领长袖白衬衫"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/m87t9ghmh.jpg-w720","fixed_price":null,"item_id":"1056350","price":"96.00","shop_type":0,"title":"一字领绑带条纹衬衫"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/pyoaqm0h5.jpg-w720","fixed_price":null,"item_id":"1056348","price":"129.00","shop_type":0,"title":"开衩不规则包臀中长半身裙"},{"cover_image_url":"http://img03.liwushuo.com/image/160517/9yerdi8p4.jpg-w720","fixed_price":null,"item_id":"1056347","price":"59.00","shop_type":0,"title":"V领针织短款短袖T恤"}],"published_at":1463788800,"share_msg":"露腿这件事情，也是需要些小心机的。比如还没能完全瘦身成功的现在，还是没有勇气直接穿上小短裙、小短裤。可是看到大家都开始纷纷露腿博关注，又按耐不住想要跟上她们的节奏。幸好最近发现一种无论腿形如何，都能轻松时髦性感露腿的单品，半露不露的美腿才更撩人～","short_title":"","status":0,"template":"","title":"第17期 ｜ 来自开衩裙的诱惑，撩汉就靠它了","type":"post","updated_at":1463543999,"url":"http://www.liwushuo.com/posts/1043431"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043499/content","cover_image_url":"http://img02.liwushuo.com/image/160520/aamq7b9l4.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160520/aamq7b9l4.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965952,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043499,"labels":[],"liked":false,"likes_count":31023,"published_at":1463799600,"share_msg":"海军风已经成为了一个独到的文化刮遍了全球。它无孔不入的钻进每个角落,得益于强势大女人风潮与中性风格的流行,英气中又透着帅气的海军风成为了今年流行元素之一，小礼君今天给美眉们推荐几款比较中意的海军元素的衣衣哦~这个夏天刮来一阵海军风~","short_title":"","status":0,"template":"","title":"第17期 | 这个夏天有\u201c海军风\u201d超凉爽的","type":"post","updated_at":1463712855,"url":"http://www.liwushuo.com/posts/1043499"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043464/content","cover_image_url":"http://img01.liwushuo.com/image/160519/pgyb03rum.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160519/pgyb03rum.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965943,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043464,"labels":[],"liked":false,"likes_count":33162,"published_at":1463713200,"share_msg":"每个人衣橱里都会有一件衬衫，但是一件衬衫式连衣裙不一定大家都有，很多人把衬衫当做很正式的服装，但是跟连衣裙搭配在一起，会迸发出不一样的火花。小礼君给大家推荐10款衬衫式连衣裙，在利落中又不失活泼，有的俏皮，有的慵懒，更可以性感的可爱。","short_title":"","status":0,"template":"","title":"第16期 | 不用偷穿男票衬衫，照样帅出高bigger","type":"post","updated_at":1463627362,"url":"http://www.liwushuo.com/posts/1043464"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043393/content","cover_image_url":"http://img01.liwushuo.com/image/160519/u1jictrr5.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160519/u1jictrr5.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463738019,"editor_id":1134,"feature_list":[],"hidden_cover_image":false,"id":1043393,"labels":[],"liked":false,"likes_count":23255,"published_at":1463702400,"share_msg":"北鼻们，初夏刚刚来到，是不是已经按耐不住鸡冻的心情在网上订机票了？阳光沙滩如此美好，入手几件沙滩行头才是正经事。别琢磨身材够不够销魂，小礼君为你们奉上的泳装不仅仅是高白瘦专属的哦！快来用这些泳装妆点你的美好肉体，度过一个美好假日吧！","short_title":"","status":0,"template":"","title":"第16期 ｜ 阳光沙滩已备好，就差一件惊艳的泳衣了","type":"post","updated_at":1463454939,"url":"http://www.liwushuo.com/posts/1043393"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043196/content","cover_image_url":"http://img01.liwushuo.com/image/160518/6gtazej2m.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160518/6gtazej2m.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651660,"editor_id":1119,"feature_list":[],"hidden_cover_image":false,"id":1043196,"labels":[],"liked":false,"likes_count":28007,"published_at":1463616000,"share_msg":"随手翻一翻各大时尚杂志、instagram、pinterest、朋友圈，简直要被绑带鞋淹没了！今夏再不入手一双，就对不起自己的芊芊玉腿！其实，绑带鞋是一路从去年火到了今年，从冬天火到了夏天，因为它能立刻让你找到属于你自己的独一无二的气场，无关乎身材，有发展成时尚长青鞋款的大势。为此，同样爱美的小礼君献上今夏10款最美绑带鞋，如果你爱她，不妨送她脚踏实地的爱。","short_title":"绑带鞋","status":0,"template":"","title":"第15期 | 今夏最美绑带鞋，送她脚踏实地的爱","type":"post","updated_at":1462773305,"url":"http://www.liwushuo.com/posts/1043196"},{"ad_monitors":[],"content_type":3,"content_url":"http://www.liwushuo.com/posts/1043376/content","cover_image_url":"http://img01.liwushuo.com/image/160517/25dx0atgj.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160517/25dx0atgj.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651586,"editor_id":1045,"feature_list":[8,1,5,6],"hidden_cover_image":false,"id":1043376,"labels":[],"liked":false,"likes_count":22657,"preview_items":[{"cover_image_url":"http://img03.liwushuo.com/image/160516/bh0jpu8s4.jpg-w720","fixed_price":null,"item_id":"1056133","price":"78.00","shop_type":0,"title":"吊带百褶连衣裙"},{"cover_image_url":"http://img02.liwushuo.com/image/160516/l5otlw5fr.jpg-w720","fixed_price":null,"item_id":"1056128","price":"58.00","shop_type":0,"title":"小清新波点立领衬衫"},{"cover_image_url":"http://img01.liwushuo.com/image/160516/t3b6okue5.jpg-w720","fixed_price":null,"item_id":"1056132","price":"65.00","shop_type":0,"title":"空气猫·高腰碎花格子吊带连衣裙"},{"cover_image_url":"http://img03.liwushuo.com/image/160516/2dumlv17a.jpg-w720","fixed_price":null,"item_id":"1056125","price":"55.00","shop_type":0,"title":"空气猫·刺绣印花T恤"},{"cover_image_url":"http://img01.liwushuo.com/image/160516/fi0odnod3.jpg-w720","fixed_price":null,"item_id":"1056117","price":"116.00","shop_type":0,"title":"DK尤物·V领花色吊带雪纺连衣裙"},{"cover_image_url":"http://img03.liwushuo.com/image/160516/xvzce1z4a.jpg-w720","fixed_price":null,"item_id":"1056122","price":"62.00","shop_type":0,"title":"DK尤物·小尖领白色短袖T恤"},{"cover_image_url":"http://img01.liwushuo.com/image/160516/cmrrmgckw_w.jpg-w720","fixed_price":null,"item_id":"1056126","price":"69.00","shop_type":0,"title":"阔色·圆领刺绣T恤"}],"published_at":1463529600,"share_msg":"世上有一种人，被称作\u201c虎背熊腰\u201d，如果不幸这个词砸中了某个姑娘，那基本上姑娘就可以和一切吊带单品说byebye了。可是，没有吊带的夏天，不完整啊～大部分人可能都会选择在外面加件罩衫，除了这个，现在又可以get一种新穿法了，穿在t恤或者衬衫外面，露出吊带裙的全貌，勾勒出好看的轮廓，还有点小性感。","short_title":"","status":0,"template":"","title":"第14期 ｜ 来玩叠穿吧！让你提前穿上吊带裙","type":"post","updated_at":1463391446,"url":"http://www.liwushuo.com/posts/1043376"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043434/content","cover_image_url":"http://img01.liwushuo.com/image/160518/yf8p2mfx4.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160518/yf8p2mfx4.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651578,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043434,"labels":[],"liked":false,"likes_count":31144,"published_at":1463626800,"share_msg":"&nbsp;小礼君很喜欢夏天，因为夏天的阳光是充满魔力了，只要是晴天！心情就会莫名的好哦，但是话又说回来！夏天也是很容易变黑的季节，那么这时候你就需要一顶遮掩帽来救助啦，下面小礼君为你们推荐了11款帽子~快来看看吧。","short_title":"","status":0,"template":"","title":"第15期 | 戴上渔夫帽和这个夏天 Say Hi","type":"post","updated_at":1463551371,"url":"http://www.liwushuo.com/posts/1043434"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043394/content","cover_image_url":"http://img03.liwushuo.com/image/160518/c9v2t79dg.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160518/c9v2t79dg.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651568,"editor_id":1132,"feature_list":[],"hidden_cover_image":false,"id":1043394,"labels":[],"liked":false,"likes_count":23496,"published_at":1463540400,"share_msg":"进入五月份，马上就迎来夏季了，你的衣橱准备好来一次大换血了吗？白色系在日常生活中实用度当之无愧，给人清爽又时髦的感觉，出门时间很紧的时候随手套上一件，百搭性很强而且绝对不会穿错，看看我们给你的推荐，都是百搭性强的，不费工夫穿上瞬间起范儿，就是这么好穿～","short_title":"白色系单品","status":0,"template":"","title":"第14期 ｜ 瞬间起范儿，最受欢迎的白色LOOK","type":"post","updated_at":1463455647,"url":"http://www.liwushuo.com/posts/1043394"}],"paging":{"next_url":"http://api.liwushuo.com/v2/channels/110/items?limit=10&offset=10"}}
     * message : OK
     */

    private int code;
    /**
     * items : [{"ad_monitors":[],"content_type":3,"content_url":"http://www.liwushuo.com/posts/1043410/content","cover_image_url":"http://img03.liwushuo.com/image/160518/bf4sc3f3m.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160518/bf4sc3f3m.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965987,"editor_id":1045,"feature_list":[8,1,5,6],"hidden_cover_image":false,"id":1043410,"labels":[],"liked":false,"likes_count":22565,"preview_items":[{"cover_image_url":"http://img.alicdn.com/imgextra/i8/TB1iyWOMXXXXXXkXVXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056246","price":"55.00","shop_type":0,"title":"竖条纹理撞色圆领短袖T恤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i3/TB1EHy6MXXXXXXXXpXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056249","price":"122.00","shop_type":0,"title":"不对称压褶休闲短裤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i2/TB1Qp5dMpXXXXa0XVXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056250","price":"143.00","shop_type":0,"title":"插肩撞色字母短袖T恤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i8/TB1Y2DiHVXXXXbLXFXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056251","price":"69.00","shop_type":0,"title":"百搭修身运动短裤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/d8xya3fh2.jpg-w720","fixed_price":null,"item_id":"1056248","price":"69.00","shop_type":0,"title":"灰白竖条短款短袖t恤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/ia9ej3o0q.jpg-w720","fixed_price":null,"item_id":"1056244","price":"79.00","shop_type":0,"title":"黑白侧条九分宽腿裤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/vwlijvteo.jpg-w720","fixed_price":null,"item_id":"1056243","price":"47.00","shop_type":0,"title":"无袖中长款可乐印花T恤"}],"published_at":1463875200,"share_msg":"最近的戛纳是个热闹的地方，因为第69届电影节来了，除了期待各项奖项花落谁家，当然就是看各家明星的街拍照过眼瘾了。除了红毯，他们平常的装扮我们还是可以学习一下的，比如，集Smart和Chic于一身的Sporty look！又时髦又实穿还能拥有舒适自由的穿衣大招get好了吗？","short_title":"运动风","status":0,"template":"","title":"第18期 ｜ 依旧不过时的运动风大势，请跟上！","type":"post","updated_at":1463472930,"url":"http://www.liwushuo.com/posts/1043410"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043500/content","cover_image_url":"http://img02.liwushuo.com/image/160520/nqyn21b3q.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160520/nqyn21b3q.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965976,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043500,"labels":[],"liked":false,"likes_count":22958,"published_at":1463886000,"share_msg":"很多女神都很喜欢偏文艺的连衣裙，因为如果衣服太甜美显得萝莉，太超酷又显得中性，太利落显得太职业了，就这种文艺范的连衣裙，简单优雅，看上去十分有质感！穿上文艺范连衣裙，你也是女神。","short_title":"","status":0,"template":"","title":"第18期 | 女神养成记，只需一条文艺范连衣裙","type":"post","updated_at":1463713623,"url":"http://www.liwushuo.com/posts/1043500"},{"ad_monitors":[],"content_type":3,"content_url":"http://www.liwushuo.com/posts/1043431/content","cover_image_url":"http://img01.liwushuo.com/image/160519/u6brosgkc.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160519/u6brosgkc.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965960,"editor_id":1045,"feature_list":[8,5,6],"hidden_cover_image":false,"id":1043431,"labels":[],"liked":false,"likes_count":24167,"preview_items":[{"cover_image_url":"http://img01.liwushuo.com/image/160517/8gsd1uk29.jpg-w720","fixed_price":null,"item_id":"1056351","price":"72.00","shop_type":0,"title":"五分袖纯棉修身打底衫"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/zdw07i65x.jpg-w720","fixed_price":null,"item_id":"1056344","price":"142.00","shop_type":0,"title":"百搭开叉中长款半身裙"},{"cover_image_url":"http://img01.liwushuo.com/image/160518/nincfphz5_w.jpg-w720","fixed_price":null,"item_id":"1056346","price":"168.00","shop_type":0,"title":"勿忘草蓝麂皮绒开衩半身裙"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/0klpv2pex.jpg-w720","fixed_price":null,"item_id":"1056349","price":"138.00","shop_type":0,"title":"宽松V领长袖白衬衫"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/m87t9ghmh.jpg-w720","fixed_price":null,"item_id":"1056350","price":"96.00","shop_type":0,"title":"一字领绑带条纹衬衫"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/pyoaqm0h5.jpg-w720","fixed_price":null,"item_id":"1056348","price":"129.00","shop_type":0,"title":"开衩不规则包臀中长半身裙"},{"cover_image_url":"http://img03.liwushuo.com/image/160517/9yerdi8p4.jpg-w720","fixed_price":null,"item_id":"1056347","price":"59.00","shop_type":0,"title":"V领针织短款短袖T恤"}],"published_at":1463788800,"share_msg":"露腿这件事情，也是需要些小心机的。比如还没能完全瘦身成功的现在，还是没有勇气直接穿上小短裙、小短裤。可是看到大家都开始纷纷露腿博关注，又按耐不住想要跟上她们的节奏。幸好最近发现一种无论腿形如何，都能轻松时髦性感露腿的单品，半露不露的美腿才更撩人～","short_title":"","status":0,"template":"","title":"第17期 ｜ 来自开衩裙的诱惑，撩汉就靠它了","type":"post","updated_at":1463543999,"url":"http://www.liwushuo.com/posts/1043431"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043499/content","cover_image_url":"http://img02.liwushuo.com/image/160520/aamq7b9l4.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160520/aamq7b9l4.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965952,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043499,"labels":[],"liked":false,"likes_count":31023,"published_at":1463799600,"share_msg":"海军风已经成为了一个独到的文化刮遍了全球。它无孔不入的钻进每个角落,得益于强势大女人风潮与中性风格的流行,英气中又透着帅气的海军风成为了今年流行元素之一，小礼君今天给美眉们推荐几款比较中意的海军元素的衣衣哦~这个夏天刮来一阵海军风~","short_title":"","status":0,"template":"","title":"第17期 | 这个夏天有\u201c海军风\u201d超凉爽的","type":"post","updated_at":1463712855,"url":"http://www.liwushuo.com/posts/1043499"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043464/content","cover_image_url":"http://img01.liwushuo.com/image/160519/pgyb03rum.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160519/pgyb03rum.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463965943,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043464,"labels":[],"liked":false,"likes_count":33162,"published_at":1463713200,"share_msg":"每个人衣橱里都会有一件衬衫，但是一件衬衫式连衣裙不一定大家都有，很多人把衬衫当做很正式的服装，但是跟连衣裙搭配在一起，会迸发出不一样的火花。小礼君给大家推荐10款衬衫式连衣裙，在利落中又不失活泼，有的俏皮，有的慵懒，更可以性感的可爱。","short_title":"","status":0,"template":"","title":"第16期 | 不用偷穿男票衬衫，照样帅出高bigger","type":"post","updated_at":1463627362,"url":"http://www.liwushuo.com/posts/1043464"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043393/content","cover_image_url":"http://img01.liwushuo.com/image/160519/u1jictrr5.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160519/u1jictrr5.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463738019,"editor_id":1134,"feature_list":[],"hidden_cover_image":false,"id":1043393,"labels":[],"liked":false,"likes_count":23255,"published_at":1463702400,"share_msg":"北鼻们，初夏刚刚来到，是不是已经按耐不住鸡冻的心情在网上订机票了？阳光沙滩如此美好，入手几件沙滩行头才是正经事。别琢磨身材够不够销魂，小礼君为你们奉上的泳装不仅仅是高白瘦专属的哦！快来用这些泳装妆点你的美好肉体，度过一个美好假日吧！","short_title":"","status":0,"template":"","title":"第16期 ｜ 阳光沙滩已备好，就差一件惊艳的泳衣了","type":"post","updated_at":1463454939,"url":"http://www.liwushuo.com/posts/1043393"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043196/content","cover_image_url":"http://img01.liwushuo.com/image/160518/6gtazej2m.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160518/6gtazej2m.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651660,"editor_id":1119,"feature_list":[],"hidden_cover_image":false,"id":1043196,"labels":[],"liked":false,"likes_count":28007,"published_at":1463616000,"share_msg":"随手翻一翻各大时尚杂志、instagram、pinterest、朋友圈，简直要被绑带鞋淹没了！今夏再不入手一双，就对不起自己的芊芊玉腿！其实，绑带鞋是一路从去年火到了今年，从冬天火到了夏天，因为它能立刻让你找到属于你自己的独一无二的气场，无关乎身材，有发展成时尚长青鞋款的大势。为此，同样爱美的小礼君献上今夏10款最美绑带鞋，如果你爱她，不妨送她脚踏实地的爱。","short_title":"绑带鞋","status":0,"template":"","title":"第15期 | 今夏最美绑带鞋，送她脚踏实地的爱","type":"post","updated_at":1462773305,"url":"http://www.liwushuo.com/posts/1043196"},{"ad_monitors":[],"content_type":3,"content_url":"http://www.liwushuo.com/posts/1043376/content","cover_image_url":"http://img01.liwushuo.com/image/160517/25dx0atgj.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160517/25dx0atgj.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651586,"editor_id":1045,"feature_list":[8,1,5,6],"hidden_cover_image":false,"id":1043376,"labels":[],"liked":false,"likes_count":22657,"preview_items":[{"cover_image_url":"http://img03.liwushuo.com/image/160516/bh0jpu8s4.jpg-w720","fixed_price":null,"item_id":"1056133","price":"78.00","shop_type":0,"title":"吊带百褶连衣裙"},{"cover_image_url":"http://img02.liwushuo.com/image/160516/l5otlw5fr.jpg-w720","fixed_price":null,"item_id":"1056128","price":"58.00","shop_type":0,"title":"小清新波点立领衬衫"},{"cover_image_url":"http://img01.liwushuo.com/image/160516/t3b6okue5.jpg-w720","fixed_price":null,"item_id":"1056132","price":"65.00","shop_type":0,"title":"空气猫·高腰碎花格子吊带连衣裙"},{"cover_image_url":"http://img03.liwushuo.com/image/160516/2dumlv17a.jpg-w720","fixed_price":null,"item_id":"1056125","price":"55.00","shop_type":0,"title":"空气猫·刺绣印花T恤"},{"cover_image_url":"http://img01.liwushuo.com/image/160516/fi0odnod3.jpg-w720","fixed_price":null,"item_id":"1056117","price":"116.00","shop_type":0,"title":"DK尤物·V领花色吊带雪纺连衣裙"},{"cover_image_url":"http://img03.liwushuo.com/image/160516/xvzce1z4a.jpg-w720","fixed_price":null,"item_id":"1056122","price":"62.00","shop_type":0,"title":"DK尤物·小尖领白色短袖T恤"},{"cover_image_url":"http://img01.liwushuo.com/image/160516/cmrrmgckw_w.jpg-w720","fixed_price":null,"item_id":"1056126","price":"69.00","shop_type":0,"title":"阔色·圆领刺绣T恤"}],"published_at":1463529600,"share_msg":"世上有一种人，被称作\u201c虎背熊腰\u201d，如果不幸这个词砸中了某个姑娘，那基本上姑娘就可以和一切吊带单品说byebye了。可是，没有吊带的夏天，不完整啊～大部分人可能都会选择在外面加件罩衫，除了这个，现在又可以get一种新穿法了，穿在t恤或者衬衫外面，露出吊带裙的全貌，勾勒出好看的轮廓，还有点小性感。","short_title":"","status":0,"template":"","title":"第14期 ｜ 来玩叠穿吧！让你提前穿上吊带裙","type":"post","updated_at":1463391446,"url":"http://www.liwushuo.com/posts/1043376"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043434/content","cover_image_url":"http://img01.liwushuo.com/image/160518/yf8p2mfx4.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160518/yf8p2mfx4.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651578,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1043434,"labels":[],"liked":false,"likes_count":31144,"published_at":1463626800,"share_msg":"&nbsp;小礼君很喜欢夏天，因为夏天的阳光是充满魔力了，只要是晴天！心情就会莫名的好哦，但是话又说回来！夏天也是很容易变黑的季节，那么这时候你就需要一顶遮掩帽来救助啦，下面小礼君为你们推荐了11款帽子~快来看看吧。","short_title":"","status":0,"template":"","title":"第15期 | 戴上渔夫帽和这个夏天 Say Hi","type":"post","updated_at":1463551371,"url":"http://www.liwushuo.com/posts/1043434"},{"ad_monitors":[],"content_type":1,"content_url":"http://www.liwushuo.com/posts/1043394/content","cover_image_url":"http://img03.liwushuo.com/image/160518/c9v2t79dg.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160518/c9v2t79dg.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1463651568,"editor_id":1132,"feature_list":[],"hidden_cover_image":false,"id":1043394,"labels":[],"liked":false,"likes_count":23496,"published_at":1463540400,"share_msg":"进入五月份，马上就迎来夏季了，你的衣橱准备好来一次大换血了吗？白色系在日常生活中实用度当之无愧，给人清爽又时髦的感觉，出门时间很紧的时候随手套上一件，百搭性很强而且绝对不会穿错，看看我们给你的推荐，都是百搭性强的，不费工夫穿上瞬间起范儿，就是这么好穿～","short_title":"白色系单品","status":0,"template":"","title":"第14期 ｜ 瞬间起范儿，最受欢迎的白色LOOK","type":"post","updated_at":1463455647,"url":"http://www.liwushuo.com/posts/1043394"}]
     * paging : {"next_url":"http://api.liwushuo.com/v2/channels/110/items?limit=10&offset=10"}
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        /**
         * next_url : http://api.liwushuo.com/v2/channels/110/items?limit=10&offset=10
         */

        private PagingBean paging;
        /**
         * ad_monitors : []
         * content_type : 3
         * content_url : http://www.liwushuo.com/posts/1043410/content
         * cover_image_url : http://img03.liwushuo.com/image/160518/bf4sc3f3m.jpg-w720
         * cover_webp_url : http://img03.liwushuo.com/image/160518/bf4sc3f3m.jpg?imageView2/2/w/720/q/85/format/webp
         * created_at : 1463965987
         * editor_id : 1045
         * feature_list : [8,1,5,6]
         * hidden_cover_image : false
         * id : 1043410
         * labels : []
         * liked : false
         * likes_count : 22565
         * preview_items : [{"cover_image_url":"http://img.alicdn.com/imgextra/i8/TB1iyWOMXXXXXXkXVXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056246","price":"55.00","shop_type":0,"title":"竖条纹理撞色圆领短袖T恤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i3/TB1EHy6MXXXXXXXXpXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056249","price":"122.00","shop_type":0,"title":"不对称压褶休闲短裤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i2/TB1Qp5dMpXXXXa0XVXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056250","price":"143.00","shop_type":0,"title":"插肩撞色字母短袖T恤"},{"cover_image_url":"http://img.alicdn.com/imgextra/i8/TB1Y2DiHVXXXXbLXFXXYXGcGpXX_M2.SS2","fixed_price":null,"item_id":"1056251","price":"69.00","shop_type":0,"title":"百搭修身运动短裤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/d8xya3fh2.jpg-w720","fixed_price":null,"item_id":"1056248","price":"69.00","shop_type":0,"title":"灰白竖条短款短袖t恤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/ia9ej3o0q.jpg-w720","fixed_price":null,"item_id":"1056244","price":"79.00","shop_type":0,"title":"黑白侧条九分宽腿裤"},{"cover_image_url":"http://img02.liwushuo.com/image/160517/vwlijvteo.jpg-w720","fixed_price":null,"item_id":"1056243","price":"47.00","shop_type":0,"title":"无袖中长款可乐印花T恤"}]
         * published_at : 1463875200
         * share_msg : 最近的戛纳是个热闹的地方，因为第69届电影节来了，除了期待各项奖项花落谁家，当然就是看各家明星的街拍照过眼瘾了。除了红毯，他们平常的装扮我们还是可以学习一下的，比如，集Smart和Chic于一身的Sporty look！又时髦又实穿还能拥有舒适自由的穿衣大招get好了吗？
         * short_title : 运动风
         * status : 0
         * template :
         * title : 第18期 ｜ 依旧不过时的运动风大势，请跟上！
         * type : post
         * updated_at : 1463472930
         * url : http://www.liwushuo.com/posts/1043410
         */

        private List<ItemsBean> items;

        public PagingBean getPaging() {
            return paging;
        }

        public void setPaging(PagingBean paging) {
            this.paging = paging;
        }

        public List<ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<ItemsBean> items) {
            this.items = items;
        }

        public static class PagingBean {
            private String next_url;

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class ItemsBean {
            private int content_type;
            private String content_url;
            private String cover_image_url;
            private String cover_webp_url;
            private int created_at;
            private int editor_id;
            private boolean hidden_cover_image;
            private int id;
            private boolean liked;
            private int likes_count;
            private int published_at;
            private String share_msg;
            private String short_title;
            private int status;
            private String template;
            private String title;
            private String type;
            private int updated_at;
            private String url;
            private List<?> ad_monitors;
            private List<Integer> feature_list;
            private List<?> labels;
            /**
             * cover_image_url : http://img.alicdn.com/imgextra/i8/TB1iyWOMXXXXXXkXVXXYXGcGpXX_M2.SS2
             * fixed_price : null
             * item_id : 1056246
             * price : 55.00
             * shop_type : 0
             * title : 竖条纹理撞色圆领短袖T恤
             */

            private List<PreviewItemsBean> preview_items;

            public int getContent_type() {
                return content_type;
            }

            public void setContent_type(int content_type) {
                this.content_type = content_type;
            }

            public String getContent_url() {
                return content_url;
            }

            public void setContent_url(String content_url) {
                this.content_url = content_url;
            }

            public String getCover_image_url() {
                return cover_image_url;
            }

            public void setCover_image_url(String cover_image_url) {
                this.cover_image_url = cover_image_url;
            }

            public String getCover_webp_url() {
                return cover_webp_url;
            }

            public void setCover_webp_url(String cover_webp_url) {
                this.cover_webp_url = cover_webp_url;
            }

            public int getCreated_at() {
                return created_at;
            }

            public void setCreated_at(int created_at) {
                this.created_at = created_at;
            }

            public int getEditor_id() {
                return editor_id;
            }

            public void setEditor_id(int editor_id) {
                this.editor_id = editor_id;
            }

            public boolean isHidden_cover_image() {
                return hidden_cover_image;
            }

            public void setHidden_cover_image(boolean hidden_cover_image) {
                this.hidden_cover_image = hidden_cover_image;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public boolean isLiked() {
                return liked;
            }

            public void setLiked(boolean liked) {
                this.liked = liked;
            }

            public int getLikes_count() {
                return likes_count;
            }

            public void setLikes_count(int likes_count) {
                this.likes_count = likes_count;
            }

            public int getPublished_at() {
                return published_at;
            }

            public void setPublished_at(int published_at) {
                this.published_at = published_at;
            }

            public String getShare_msg() {
                return share_msg;
            }

            public void setShare_msg(String share_msg) {
                this.share_msg = share_msg;
            }

            public String getShort_title() {
                return short_title;
            }

            public void setShort_title(String short_title) {
                this.short_title = short_title;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getTemplate() {
                return template;
            }

            public void setTemplate(String template) {
                this.template = template;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public int getUpdated_at() {
                return updated_at;
            }

            public void setUpdated_at(int updated_at) {
                this.updated_at = updated_at;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public List<?> getAd_monitors() {
                return ad_monitors;
            }

            public void setAd_monitors(List<?> ad_monitors) {
                this.ad_monitors = ad_monitors;
            }

            public List<Integer> getFeature_list() {
                return feature_list;
            }

            public void setFeature_list(List<Integer> feature_list) {
                this.feature_list = feature_list;
            }

            public List<?> getLabels() {
                return labels;
            }

            public void setLabels(List<?> labels) {
                this.labels = labels;
            }

            public List<PreviewItemsBean> getPreview_items() {
                return preview_items;
            }

            public void setPreview_items(List<PreviewItemsBean> preview_items) {
                this.preview_items = preview_items;
            }

            public static class PreviewItemsBean {
                private String cover_image_url;
                private Object fixed_price;
                private String item_id;
                private String price;
                private int shop_type;
                private String title;

                public String getCover_image_url() {
                    return cover_image_url;
                }

                public void setCover_image_url(String cover_image_url) {
                    this.cover_image_url = cover_image_url;
                }

                public Object getFixed_price() {
                    return fixed_price;
                }

                public void setFixed_price(Object fixed_price) {
                    this.fixed_price = fixed_price;
                }

                public String getItem_id() {
                    return item_id;
                }

                public void setItem_id(String item_id) {
                    this.item_id = item_id;
                }

                public String getPrice() {
                    return price;
                }

                public void setPrice(String price) {
                    this.price = price;
                }

                public int getShop_type() {
                    return shop_type;
                }

                public void setShop_type(int shop_type) {
                    this.shop_type = shop_type;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }
            }
        }
    }
}
